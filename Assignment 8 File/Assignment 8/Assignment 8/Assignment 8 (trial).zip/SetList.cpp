// File name: a_r815_assignment8.cpp
//
// Author: Aravind Rajadurai
// Date: 4/11/2018
// Assignment Number: 8
// CS 2308, Spring 2018
// Instructor: Patricia Carando
//
//  SetList.cpp
//  Assignment 8
//
//  Created by Aravind Adric on 4/11/18.
//  Copyright © 2018 Aravind Adric. All rights reserved.
//

#include "List.h"
#include "SetList.h"
#include "SortedList.h"

//#include <iostream>

SetList::SetList()
{
    sortedList = new SortedList();
}

void SetList::addValue(int value)
{
    sortedList->insertValue(value);
}

bool SetList::containsValue(int value)
{
    return sortedList->containsValue(value);
}

bool SetList::isEmpty()
{
    return sortedList->isEmpty();
}

void SetList::print()
{
    sortedList->print();
}

void SetList::removeValue(int value)
{
    sortedList->removeValue(value);
}

SetList::~SetList()
{
    sortedList-> List::~List();
}
