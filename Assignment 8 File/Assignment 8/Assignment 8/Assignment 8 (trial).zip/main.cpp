// File name: a_r815_assignment8.cpp
//
// Author: Aravind Rajadurai
// Date: 4/11/2018
// Assignment Number: 8
// CS 2308, Spring 2018
// Instructor: Patricia Carando
//
//  main.cpp
//
//  Created by Aravind Adric on 4/11/18.
//  Copyright © 2018 Aravind Adric. All rights reserved.
//
//

#include "List.h"
#include "ListNode.h"
#include "SortedList.h"
#include "SetList.h"

//#include <iostream>

int main () {
    
    SortedList *sortedList = new SortedList ();
    
    sortedList->insertValue (22);
    sortedList->insertValue (1);
    sortedList->insertValue (-99);
    sortedList->insertValue (100);
    sortedList->insertValue (0);
    sortedList->insertValue (1);
    sortedList->print();
    
    std::cout << "\nRemoving value (22)" << std::endl;
    sortedList->removeValue(22);
    sortedList->print();
    
    std::cout << "\nRemoving value (1)" << std::endl;
    sortedList->removeValue(1);
    sortedList->print();
    
    delete sortedList;
    
    SetList *setList = new SetList();
    setList->addValue(22);
    setList->addValue(1);
    setList->addValue(-99);
    setList->addValue(0);
    setList->addValue(1);
    
    
    std::cout << "\nValues in new SetList" << std::endl;
    setList->print();
    
    delete setList;
    
    return 0;
}

